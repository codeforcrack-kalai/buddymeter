<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <title>SWP Framework</title>
		<link type="text/css" rel="stylesheet" href="general.css" />
</head>
<body>
<div id="page">
<div id="header">
<a href="http://happyworm.com/jquery/jplayer"><img src="graphics/jplayer_logo.gif" alt="jplayer" /></a><h1>Single Page Web App Demo</h1>   
</div>
<?$tab=2; include 'body.php' ?>   
</div>
</body> 

</html>